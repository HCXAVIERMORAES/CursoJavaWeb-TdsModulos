package constante;

public class StatusAluno {
	/*Classe e atributos estat�cos, ou conhecidas como constante, a variavel � maiuscula*/
	public static String APROVADO = "Aprovado";
	public static String REPROVADO = "Reprovado";
	public static String RECUPERACAO = "Recuperacao";	
}
