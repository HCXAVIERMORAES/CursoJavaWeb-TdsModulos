package cursojava.thread.telaswing;

public class ExecutarTela {

	public static void main(String[] args) {
		// Fazendo uma tela em swing para uso de thread
		TelaTimeThread telaTimeThread = new TelaTimeThread();//criando objeto da classe

	}

}
