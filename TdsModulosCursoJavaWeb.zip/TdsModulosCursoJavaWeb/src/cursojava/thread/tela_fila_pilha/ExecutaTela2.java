package cursojava.thread.tela_fila_pilha;

public class ExecutaTela2 {

	public static void main(String[] args) {
		Tela2TimeThread tela2TimeThread = new Tela2TimeThread();//criando objeto da classe

	}

}
